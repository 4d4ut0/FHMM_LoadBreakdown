package com.testobject.httprequest.Fragments;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.common.io.ByteStreams;
import com.google.gson.Gson;
import com.testobject.httprequest.LoginActivity;
import com.testobject.httprequest.R;
import com.testobject.httprequest.respConsumo.Consumo;
import com.testobject.httprequest.respConsumo.respConsumo;
import com.testobject.httprequest.respDevice.Device;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import lecho.lib.hellocharts.view.LineChartView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DiarioFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DiarioFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    // TODO: Rename and change types of parameters
    private String mParam1;
    private Integer mParam2;
    private String fullUrl;
    private String urlInicial = "http://192.168.0.30/api/consumo/";
    private String api = "/diario/";
    private String urlDevice = "http://192.168.0.30/api/estacao/usuario/";
    private Device[] deviceList;
    private ArrayList<Consumo> respsConsumos;
    private ArrayList<String> x;
    private ArrayList<Float> y;
    private ProgressDialog progressDialog;
    private LineChartView lineChartView;
    private View rootView;
    public DiarioFragment() {
        // Required empty public constructor
    }
    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static DiarioFragment newInstance(String param1, Integer param2) {
        DiarioFragment fragment = new DiarioFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putInt(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getInt(ARG_PARAM2);
        }

        fullUrl = urlInicial + mParam2 + api + "18/04/2011";
        startDialog("Buscando dados de consumo", "Tiruriruriruruuuu, rururu, rurururuuuuu");
        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {
                try  {

                    deviceList = getDevices(mParam2);
                    Log.v("idEstacao", Integer.toString(deviceList[0].getIdEstacao()));
                    respsConsumos = findConsumoByIdEstacao(1345,"19/04/2011");
                    Log.v("heuheuhe", Integer.toString(respsConsumos.size()));
                    y = findPotenciaConsumo();
                    x = findDataConsumo();
                    progressDialog.dismiss();

                } catch (Exception e) {
                    Log.e("iririr", "Erro no parsing do JSON", e);
                }
            }
        });
        thread.start();

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_diario, container, false);


        return rootView;
    }

    public Device[] getDevices(Integer userId){
        try {
            final java.net.URL url = new URL(urlDevice+userId);
            final HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.connect();

            final InputStream stream = connection.getInputStream();
            String oloco = new String(ByteStreams.toByteArray(stream));
            Device[] msg = new Gson().fromJson(oloco, Device[].class);
            return msg;
        } catch (Exception e) {
            Log.e("Your tag", "Error", e);
        }
        return null;
    }

    public respConsumo get(Integer estacaoId, String data){
        try {
            final java.net.URL url = new URL(urlInicial+estacaoId+api+data);
            final HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.connect();

            final InputStream stream = connection.getInputStream();
            String oloco = new String(ByteStreams.toByteArray(stream));
            respConsumo msg = new Gson().fromJson(oloco, respConsumo.class);
            return msg;
        } catch (Exception e) {
            Log.e("Your tag", "Error", e);
        }
        return null;
    }

    public ArrayList<Consumo> findConsumoByIdEstacao(Integer idEstacao, String data){
        for (Device device:deviceList)
            if(device.getIdEstacao().equals(1345)) return get(device.getIdEstacao(),data).getConsumos();

        return null;
    }

    public ArrayList<String> findDataConsumo (){
        ArrayList<String> resp = new ArrayList<>();
        for (Consumo consumo: respsConsumos)
            resp.add(consumo.getDataTimeInsere().split("T")[1])  ;

        return resp;
    }

    public ArrayList<Float> findPotenciaConsumo (){
        ArrayList<Float> resp = new ArrayList<>();
        for (Consumo consumo: respsConsumos)
            resp.add(consumo.getPotencia())  ;

        return resp;
    }

    public void startDialog(String title, String msg){
        progressDialog = new ProgressDialog(getContext());
        progressDialog.setIndeterminate(true);
        progressDialog.setTitle(title);
        progressDialog.setMessage(msg);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setMax(100);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
    }

}
