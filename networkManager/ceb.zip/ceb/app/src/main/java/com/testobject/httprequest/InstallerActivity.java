package com.testobject.httprequest;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.google.common.io.ByteStreams;
import com.google.gson.Gson;
import com.testobject.httprequest.respJsonInstaller.ResultInstaller;
import com.testobject.httprequest.respJsonInstaller.respJsonInstaller;
import com.testobject.httprequest.respJsonLogin.respJsonLogin;

import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import butterknife.OnItemClick;

import static java.lang.Thread.sleep;

public class InstallerActivity extends AppCompatActivity {
    private static final int REQUEST_SIGNUP = 0;
    private respJsonLogin respJson;
    private respJsonInstaller installer;
    static String ipWoxintonn = "http://192.168.0.30/api/Usuario/ObterUsuarioPorPerfil";
    private ProgressDialog progressDialog;
    private String cookieName;
    private String cookieValue;
    private ListView lv;
    private ArrayAdapter<String> adapter;
    private EditText inputSearch;
    private AlertDialog.Builder userDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_installer);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (bundle != null){
            respJson = (respJsonLogin) getIntent().getSerializableExtra("json");
            cookieName = (String) getIntent().getSerializableExtra("cookieName");
            cookieValue = (String) getIntent().getSerializableExtra("cookieValue");
            Log.v("msg", Integer.toString(respJson.getResult().getIdUsuario()));
            Log.v("name", cookieName);
            Log.v("value", cookieValue);
        }

        getUserList();

        lv = findViewById(R.id.list_view);
        //inputSearch = findViewById(R.id.inputSearch);

       /*inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                adapter.getFilter().filter(charSequence);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });*/

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                startUserDialog(installer.getAllNameUser().get(i),installer.getAllIdUser().get(i));
            }
        });

    }

    public respJsonInstaller post(){
        try {
            final java.net.URL url = new URL(ipWoxintonn);
            final HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            String cookie = cookieName + "=" + cookieValue +"; domain=192.168.0.30";
            connection.setRequestProperty("Cookie", cookie);
            connection.connect();

            final InputStream stream = connection.getInputStream();
            String oloco = new String(ByteStreams.toByteArray(stream));
            Log.v("meuuuuu, amigo", oloco);
            respJsonInstaller msg = new Gson().fromJson(oloco, respJsonInstaller.class);
            return msg;
        } catch (Exception e) {
            Log.e("Your tag", "Error", e);
        }

        return null;
    }

    public void getUserList(){
        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {
               installer = post();
               List<String> allNames = installer.getAllNameUser();
                for(int i = 0; i < installer.getAllIdUser().size(); i++) {
                    Log.v(Integer.toString(i), installer.getAllNameUser().get(i) );
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        List<String> allNames = installer.getAllNameUser();
                        adapter = new ArrayAdapter<>(InstallerActivity.this, R.layout.list_item, R.id.product_name, allNames);
                        lv.setAdapter(adapter);
                    }
                });
            }
        });
        thread.start();
    }

    public void startUserDialog(final String name, final Integer idUsuario){
        userDialog= new AlertDialog.Builder(this);
        userDialog.setTitle(name);
        userDialog.setMessage("Sabiamente o caminho, escolher, voce deve!!xD");
        userDialog.setPositiveButton("Monitorar", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                sendMonitoramento(idUsuario, name);
            }
        });
        userDialog.setNeutralButton("Novo Aparelho", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                sendNewDV(idUsuario, name);
            }
        });
        AlertDialog alerta = userDialog.create();
        alerta.show();
    }

    public void sendNewDV(Integer id, String name){
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("userName", name);
        bundle.putInt("userId", id);
        intent.putExtras(bundle);
        startActivityForResult(intent, REQUEST_SIGNUP);
    }

    public void sendMonitoramento(Integer id, String name){
        Intent intent = new Intent(getApplicationContext(), UserConsumoActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("userName", name);
        bundle.putInt("userId", id);
        intent.putExtras(bundle);
        startActivityForResult(intent, REQUEST_SIGNUP);
    }

}
