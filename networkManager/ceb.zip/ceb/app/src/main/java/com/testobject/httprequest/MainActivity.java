package com.testobject.httprequest;

import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.net.ProxySelector;
import java.net.URI;
import com.spark.submitbutton.SubmitButton;
import com.testobject.httprequest.respJsonLogin.respJsonLogin;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    static String ipWoxintonn = "http://192.168.4.1/?";
    static String responseCode = "";
    static String endpoint = "";
    private ImageView ImgLogo;
    private TextView TxtPassword;
    private TextInputEditText TxtSSID;
    private TextView TxtName;
    private TextView Txthpinicial;
    private TextView Txthpfinal;
    private TextView TxtPotencia;
    private TimePickerDialog picker;
    private TextView responseStatusField;
    private SubmitButton get;
    private String resp;
    private ProgressDialog dialog;
    private Integer i;
    private String userName;
    private Integer userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (bundle != null){
            userName = getIntent().getStringExtra("userName");
            userId = getIntent().getIntExtra("userId",0);
        }


        ImgLogo = findViewById(R.id.imageView);
        TxtSSID =  findViewById(R.id.txt_ssid);
        TxtPassword = (TextView) findViewById(R.id.txt_password);
        TxtName = (TextView) findViewById(R.id.txt_name);
        Txthpinicial = findViewById(R.id.txt_ponto_inicial);
        Txthpfinal = findViewById(R.id.txt_ponto_final);
        TxtPotencia = findViewById(R.id.potencia);
        get = findViewById(R.id.button);
        responseStatusField = (TextView) findViewById(R.id.response_status);
        Button clear = (Button) findViewById(R.id.buttonClear);
        dialog = new ProgressDialog(MainActivity.this);



        Txthpinicial.setInputType(InputType.TYPE_NULL);
        Txthpinicial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int hour = cldr.get(Calendar.HOUR_OF_DAY);
                int minutes = cldr.get(Calendar.MINUTE);
                // time picker dialog
                picker = new TimePickerDialog(MainActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker tp, int sHour, int sMinute) {
                                Txthpinicial.setText(Integer.toString(sHour));
                            }
                        }, hour, minutes, true);
                picker.show();
            }
        });

        Txthpfinal.setInputType(InputType.TYPE_NULL);
        Txthpfinal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int hour = cldr.get(Calendar.HOUR_OF_DAY);
                int minutes = cldr.get(Calendar.MINUTE);
                // time picker dialog

                picker = new TimePickerDialog(MainActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker tp, int sHour, int sMinute) {
                                Txthpfinal.setText(Integer.toString(sHour));
                            }
                        }, hour,minutes, true);
                picker.show();
            }
        });

        if (savedInstanceState == null) {
            get.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    responseStatusField.setText(null);
                    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"),
                            Locale.getDefault());
                    Date currentLocalTime = calendar.getTime();

                    DateFormat date = new SimpleDateFormat("ZZZZZ",Locale.getDefault());
                    endpoint = ipWoxintonn +
                            "ssid=" + TxtSSID.getText().toString() +
                            "&password=" + TxtPassword.getText().toString() +
                            "&type=" + TxtName.getText().toString() +
                            "&hpi=" + Txthpinicial.getText().toString() +
                            "&hpf=" + Txthpfinal.getText().toString() +
                            "&pt=" + TxtPotencia.getText().toString() +
                            "&fuso=" + date.format(currentLocalTime);
                    resp = getResponse(endpoint);
                    Log.v("endpoint", endpoint);
                    Log.v("resp", resp);
                    resp = getResponse(ipWoxintonn + "free=true");
                    Log.v("resp dly", resp);
                    startDialog( );

                }
            });

            clear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    responseStatusField.setText(null);
                    TxtSSID.setText(null);
                    TxtPassword.setText(null);
                    TxtName.setText(null);
                    get.refreshDrawableState();
                }
            });

            ImgLogo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    responseStatusField.setText(null);
                    TxtSSID.setText(null);
                    TxtPassword.setText(null);
                    TxtName.setText(null);
                    get.refreshDrawableState();
                }
            });
        }
    }

    private void startDialog(){
        dialog.setTitle("Conectando");
        dialog.setMessage("Calma lá que já conecta...");
        dialog.setCanceledOnTouchOutside(false);
        dialog.setMax(100);
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.show();

        Handler handler = new Handler();

        Timer timer = new Timer();
        i = 0;
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                i++;
                resp = getResponse(ipWoxintonn + "seraQ=true&foiMesmo=true");

                if("Full Conectado".equals(resp)) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            responseStatusField.setText("Conexão Realizada com Sucesso! xD");
                        }
                    });
                    dialog.dismiss();
                    return;
                }
                else if( i > 10){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            responseStatusField.setText("Falha ao conectar na rede :'(");
                        }
                    });
                    dialog.dismiss();
                    return;
                }

            }
        }, 2000, 2000);
    }

    private String getResponse(String endpoint) {
        HttpHelper helper = new HttpHelper();
        String result = "";
        try {
            result = helper.execute(endpoint).get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        responseCode = HttpHelper.getResponseCode();
        return result;
    }
}
