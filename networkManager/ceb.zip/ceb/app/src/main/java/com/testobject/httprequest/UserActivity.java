package com.testobject.httprequest;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.testobject.httprequest.respJsonLogin.respJsonLogin;

public class UserActivity extends AppCompatActivity {
    private static final int REQUEST_SIGNUP = 0;
    private respJsonLogin respJson;
    private TextView  txtPablo;
    private Button btnMonitor;
    private Button btnNewDV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (bundle != null){
            respJson = (respJsonLogin) getIntent().getSerializableExtra("json");
            Log.v("msg", Integer.toString(respJson.getResult().getIdUsuario()));
        }

        txtPablo = findViewById(R.id.pablo);
        btnMonitor = findViewById(R.id.buttonMonitor);
        btnNewDV = findViewById(R.id.buttonNewDV);

        txtPablo.setText("Jovem "+respJson.getResult().getNome()+", sabiamente o caminho, escolher, voce deve!!xD");
        btnNewDV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendNewDV(respJson.getResult().getIdUsuario(),respJson.getResult().getNome());
            }
        });
        btnMonitor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMonitoramento(respJson.getResult().getIdUsuario(),respJson.getResult().getNome());
            }
        });

    }

    public void sendNewDV(Integer id, String name){
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("userName", name);
        bundle.putInt("userId", id);
        intent.putExtras(bundle);
        startActivityForResult(intent, REQUEST_SIGNUP);
    }

    public void sendMonitoramento(Integer id, String name){
        Intent intent = new Intent(getApplicationContext(), UserConsumoActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("userName", name);
        bundle.putInt("userId", id);
        intent.putExtras(bundle);
        startActivityForResult(intent, REQUEST_SIGNUP);
    }

}
