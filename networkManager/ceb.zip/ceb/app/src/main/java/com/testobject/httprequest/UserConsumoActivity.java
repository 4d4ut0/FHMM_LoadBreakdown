package com.testobject.httprequest;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import com.testobject.httprequest.Fragments.AnualFragment;
import com.testobject.httprequest.Fragments.DiarioFragment;
import com.testobject.httprequest.Fragments.MensalFragment;


public class UserConsumoActivity extends AppCompatActivity {

    private String userName;
    private Integer userId;
    private BottomNavigationView bottomNavigation;
    private Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_consumo);
        bottomNavigation = findViewById(R.id.bottom_navigation);
        bottomNavigation.setOnNavigationItemSelectedListener(navigationItemSelectedListener);

        Intent intent = getIntent();
        bundle = intent.getExtras();
        if (bundle != null){
            userName = getIntent().getStringExtra("userName");
            userId = getIntent().getIntExtra("userId",0);
        }

        openFragment(DiarioFragment.newInstance(userName, userId));

    }

    public void openFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    BottomNavigationView.OnNavigationItemSelectedListener navigationItemSelectedListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.navigation_diario:
                            openFragment(DiarioFragment.newInstance(userName, userId));
                            return true;
                        case R.id.navigation_mensal:
                            openFragment(MensalFragment.newInstance("", ""));
                            return true;
                        case R.id.navigation_anual:
                            openFragment(AnualFragment.newInstance("", ""));
                            return true;
                        case R.id.navigation_ia:
                            openFragment(DiarioFragment.newInstance(userName, userId));
                            return true;
                    }
                    return false;
                }
            };

}
